from PIL import Image
from pdf2image import convert_from_path
import pyocr
import pyocr.builders
import cv2
import numpy as np
import os
import glob
from pathlib import Path

POPPLER_DIR = "poppler/Library/bin"
PDF_DIR = "pdf"
IMAGES_DIR = "images"

def main():
    pdfs_path = get_pdfs_path(PDF_DIR)
    for pdf_path in pdfs_path:
        print('変換中ファイル：' + os.path.basename(pdf_path))
        pdf_image = pdf_to_imageobject(pdf_path, POPPLER_DIR)
        output_dir = os.path.join(IMAGES_DIR, os.path.splitext(os.path.basename(pdf_path))[0])
        pillowimage_to_imagefile(pdf_image, output_dir)

# PDF ファイルのパスを一括取得
def get_pdfs_path(input_dir):
    pdf_path = os.path.join(Path(__file__).parent, input_dir)
    pdfs_path = glob.glob(os.path.join(pdf_path, '*.pdf'))
    return pdfs_path

# PDF を Pillow Image オブジェクトに変換
def pdf_to_imageobject(pdf_path, poppler_dir, dpi = 300):
    poppler_path = os.path.join(Path(__file__).parent, poppler_dir)
    images = convert_from_path(pdf_path=pdf_path, poppler_path=poppler_path, dpi=dpi)
    return images

# Pillow Image オブジェクトを画像ファイルに変換し保存
def pillowimage_to_imagefile(images, output_dir):
    image_dir = os.path.join(Path(__file__).parent, output_dir)
    os.makedirs(image_dir, exist_ok=True)
    for i, image in enumerate(images):
        image_name = str(i + 1) + ".png"
        image_path = os.path.join(image_dir, image_name)
        image.save(image_path, "PNG")

def render_doc_text():
    # ツール取得
    #pyocr.tesseract.TESSERACT_CMD = 'tesseract-ocr-w64-setup-5.5.0.20241111.exe'
    #pyocr.tesseract.TSSERACT_CMD = 'C:\Program Files\Tesseract-OCR\tesseract.exe'
    os.environ["TESSDATA_PREFIX"] = "C:/Users/Owner/Desktop/python/ocr/tessdata"

    tools = pyocr.get_available_tools()
    tool = tools[0]
    # 画像取得

    main()
    for file in os.listdir("pdf"):
        if file.split(".")[-1] != "pdf":
            continue
        print(f"images/{file.split('.')[0]}")
        for image in os.listdir(f"images/{file.split('.')[0]}"):
            #image = convert_from_path(file, 500)
            #image.save('sample.png', "PNG")
            image_path = f"images/{file.split('.')[0]}/{image}"
            img = cv2.imread(image_path, 0)
            # 必要に応じて画像処理 線を消す
            ret, img = cv2.threshold(img, 150, 255, cv2.THRESH_BINARY)
            img = cv2.bitwise_not(img)
            label = cv2.connectedComponentsWithStats(img)
            data = np.delete(label[2], 0, 0)
            new_image = np.zeros((img.shape[0], img.shape[1]))+255
            for i in range(label[0]-1):
                if 0 < data[i][4] < 1000:
                    new_image = np.where(label[1] == i+1, 0, new_image)
            cv2.imwrite('sample_edited.png', new_image)
            img = Image.fromarray(new_image)
            #print(img.dtype)
            #if img.dtype != 'uint8':
            #    img = cv2.convertScaleAbs(img)
            # OCR
            builder = pyocr.builders.TextBuilder()
            result = tool.image_to_string(img, lang="eng", builder=builder)
            # 結果から空白文字削除
            data_list = [text for text in result.split('\n') if text.strip()]
            data_list
            return data_list


data_list = render_doc_text()
print(data_list)
print(','.join(data_list))
with open("output", "w", encoding = "utf-8") as fo:
    fo.write(','. join(data_list))