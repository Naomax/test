import requests
from bs4 import BeautifulSoup

url = "https://news.yahoo.co.jp/"
response = requests.get(url)
html = response.text
soup = BeautifulSoup(html, "html.parser")
title = soup.find("h1")
links = soup.find_all("a")

cnt = 0
for a in links:
    if url in a.get("href"):
        cnt += 1
        print(cnt, a.text)


def search(env, idx=None):

    def summarize(env, soup):
        content = "\n".join([p.text for p in soup.find_all("p")])
        return content

    if idx == None:
        response = requests.get(env.url + "/")
    else:
        response = requests.get(env.url + "/" + env.link_list[idx])

    html = response.text
    soup = BeautifulSoup(html, "html.parser")
    title = soup.find("title")
    prompt += f"title：{title}"
    prompt += f"contents:\n"
    prompt += summarize(env, soup)
    prompt += "\n"
    prompt += "-- search index --\n"
    cnt = 0
    for a in soup.find_all("a"):
        if env.url in a.get("href"):
            cnt += 1
            prompt += f"{cnt}. {a.text}"
    return prompt

def get_current_page(env):

    def summarize(env, soup):
        content = "\n".join([p.text for p in soup.find_all("p")])
        return content

    response = requests.get(env.url + "/" + env.current_directory)
    html = response.text
    soup = BeautifulSoup(html, "html.parser")
    title = soup.find("title")
    prompt += f"title：{title}"
    prompt += f"contents:\n"
    prompt += summarize(env, soup)
    prompt += "\n"
    prompt += "-- search index --\n"
    cnt = 30
    for a in soup.find_all("a"):
        if env.url in a.get("href"):
            cnt += 1
            prompt += f"{cnt}. {a.text}"
    return prompt