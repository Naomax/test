import copy
import model
import prompt
import requests
import react
from bs4 import BeautifulSoup

class Page:
    def __init__(self, url, directory):
        self.url = url
        self.directory = directory
        self.link_dict = dict()
        def summarize(self, soup):
            content = "\n".join([p.text for p in soup.find_all("p")])
            return content

        response = requests.get(self.url + "/" + self.directory)

        html = response.text
        soup = BeautifulSoup(html, "html.parser")
        self.title = soup.find("title")
        self.content = summarize(self, soup)
        try:
            self.score = prompt.getScore(f"title:{self.title}\nsummary:{self.content}")
            self.score = float(self.score)
        except:
            print("invalid score")
            exit()

        cnt = 0
        for a in soup.find_all("a"):
            if self.url in a.get("href"):
                cnt += 1
                self.link_dict[str(cnt)] = a
    
    def getSummaryPrompt(self):
        prompt = f"title:{self.title}\n"
        prompt += f"contents:\n"
        prompt += self.content
        prompt += f"\n"
        prompt += f"-- search index --\n"
        for idx in self.link_dict:
            prompt += f"{idx}. {self.link_dict[idx].text}\n"
        return prompt
    

class Env:
    def __init__(self, client):
        self.system = "あなたは、日本の経済動向について調査する優秀なジャーナリストです。"
        self.trial = 0
        self.url = "https://news.yahoo.co.jp/"
        self.page_dict = dict()
        self.current_page = Page(self.url, "")
        self.previous_page = None
        self.page_dict[""] = copy.deepcopy(self.current_page)
        self.messages = prompt.reset(self)
        self.client = client

    def step(self):
        self.trial += 1
        print(self.messages)
        response = react.get_completion(self.messages)
        print(response)
        print("=========")
        print(response.choices[0].message.content.strip())
        response_message = response.choices[0].message.content.strip()
        self.messages.append({'role': 'assistant', 'content': response_message})
        with open("chat_history", "a", encoding = "utf-8") as fo:
            fo.write("\nchat gpt : \n")
            fo.write(str(response_message))
        self.messages.append({'role': 'user', 'content': prompt.getObservation(self, response_message)})
        with open("chat_history", "a", encoding = "utf-8") as fo:
            fo.write("\nuser : \n")
            fo.write(self.messages[-1]['content'])