import copy
import model
import prompt
import requests
import react
from bs4 import BeautifulSoup
import traceback
from selenium import webdriver
from urllib.parse import urljoin
import time
base_url =  "https://news.yahoo.co.jp/"

class Page:
    def __init__(self, url):
        self.url = url
        self.link_dict = dict()

        # response = requests.get(self.url)
        driver = webdriver.Chrome()
        print("open web driver")
        print(self.url)
        try:
            driver.get(self.url)
        

            html = driver.page_source
            soup = BeautifulSoup(html, "html.parser")

            self.title = soup.find("title")
            self.content = prompt.summarize(prompt, soup.get_text())
            status = "wait"
            while status == "wait":
                with open("status", "r", encoding = "utf-8") as fi:
                    for row in fi:
                        status = row
                time.sleep(1)
            
            with open("response", "w", encoding = "utf-8") as fo:
                fo.write(self.content)

            try:
                self.score, self.reason = prompt.getScore(f"title:{self.title}\nsummary:{self.content}")
                self.score = float(self.score)
            except:
                traceback.print_exc()
                print("invalid score")
                exit()

            cnt = 0
            for a in soup.find_all("a"):
                absolute_url = urljoin(base_url, a.get("href"))
                #print(base_url in absolute_url, a.get("href"))
                if base_url in absolute_url:
                    cnt += 1
                    self.link_dict[f"{str(cnt)}"] = a
        finally:
            time.sleep(5)
            driver.quit()
            
    
    def getSummaryPrompt(self):
        prompt = f"title:{self.title}\n"
        prompt += f"contents:\n"
        prompt += self.content
        prompt += f"\n"
        prompt += f"-- search index --\n"
        for idx in self.link_dict:
            prompt += f"{idx}. {self.link_dict[idx].text}\n"
        return prompt
    

class Env:
    def __init__(self, client):
        self.system = "あなたは、主に半導体やAI,IT,世界情勢や景気動向について調査する優秀なジャーナリストです。"
        self.trial = 0
        self.url = base_url
        self.page_dict = dict()
        self.current_page = Page(self.url)
        self.previous_page = None
        self.page_dict[""] = copy.deepcopy(self.current_page)
        self.messages = prompt.reset(self)
        self.client = client

    def step(self):
        self.trial += 1
        response = react.get_completion(self.messages)
        response_message = response.choices[0].message.content.strip()
        self.messages.append({'role': 'assistant', 'content': response_message})
        with open("chat_history", "a", encoding = "utf-8") as fo:
            fo.write("\nchat gpt : \n")
            fo.write(str(response_message))
        if response_message.count("[") == 1 and response_message.count("]") == 1 and ("think" in response_message or "analyze_search_index" in response_message or "conclude_which_page_to_jump" in response_message):
            with open("response", "w", encoding = "utf-8") as fo:
                fo.write(str(response_message.split("[")[1].split("]")[0]))
        self.messages.append({'role': 'user', 'content': prompt.getObservation(self, response_message)})
        with open("chat_history", "a", encoding = "utf-8") as fo:
            fo.write("\nuser : \n")
            fo.write(self.messages[-1]['content'])