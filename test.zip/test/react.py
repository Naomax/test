import os
import openai
import prompt
import model
from openai import OpenAI
import os
import time
import traceback

os.environ["OPENAI_API_KEY"] = ""
client = OpenAI()

def get_completion(messages):
    response = client.chat.completions.create(
        model = "gpt-4o-mini",
        messages = messages,
        temperature = 0.1
    )
    return response

def run():
    env = model.Env(client)
    num_of_episodes = 1
    num_of_steps =20
    for e in range(num_of_episodes):
        for s in range(num_of_steps):
            status = "wait"
            while status == "wait":
                with open("status", "r", encoding = "utf-8") as fi:
                    for row in fi:
                        status = row
                time.sleep(1)
            env.step()
    page_list = []
    for idx in env.page_dict:
        page_list.append(env.page_dict[idx])
    page_list = sorted(page_list, key = lambda x:x.score, reverse = True)
    with open("result", "w", encoding = "utf-8") as fo:
        for i, page in enumerate(page_list):
            fo.write(f"{i+1}. score : {page.score}\n")
            fo.write(f"title : {page.title}\n")
            fo.write(f"url : {page.url}/")
            fo.write(f"summary : {page.content}\n")
            fo.write("\n-------------------------------------------\n")

if __name__ == "__main__":
    run()