import tool
import model
import copy
import react

def reset(env):
    messages = [{"role":"system", "content": env.system}]
    question = "に関する業界動向の記事を集めてください。ステップに分けて考えてく進めてください。一度に複数の行動を選択してはいけません。\n下記の回答フォーマットから、行動を選択してください。\n"
    question += "現在のページは下記の通りです。\n"

    question += env.current_page.getSummaryPrompt()

    question += "-------- action format ----------"
    question += "think[your thought]\n"
    question += "analyze_search_index[your analysis]"
    question += "search[番号]\n"
    question += "go_back_to_main_page[]\n"
    question += "go_back_to_previous_page[]\n"

    messages.append({'role':'user', 'content': question})
    messages.append({'role':'assistant', 'content': "think[に関する記事を探すために、関連するトピックスを検索する必要があります。]"})
    messages.append({'role':'user', 'content': "observation：OKです。続けてください。"})

    return messages

def getScore(summary):
    messages = [{'role':'system', 'content': "あなたは、経済動向について調査する優秀なジャーナリストです。"}]
    messages.append({'role':'user', 'content': f"以下の記事に関して、あなたの調査対象として適切でしょうか。関連度合い、重要度合いを回答フォーマットに従って0～1の数値で答えてください。\n--回答フォーマット--\nscore:XXX\nreason:XXX\n --記事の内容--\n{summary}"})
    response = react.client.chat.completions.create(
        model = "gpt-4o-mini",
        messages = messages,
        temperature = 0.1
    )
    response_message = response.choices[0].message.content.strip()
    score = response_message.split(":")[1].split("\n")[0]
    print(f"score : {score}\n", response_message)
    return score

def getObservation(env, response):
    if response.count("[") > 1:
        prompt = "observation:Error:Invalid action. Several actions were found. \nPlease choose one action from the following action list.\n"
        prompt += "-------- action format ----------"
        prompt += "think[your thought]\n"
        prompt += "analyze_search_index[your analysis]"
        prompt += "search[番号]\n"
        prompt += "go_back_to_main_page[]\n"
        prompt += "go_back_to_previous_page[]\n"
        return prompt
    if response.startswith("think[") or response.startswith("analyze_search_index["):
        prompt = "observation：OKです。続けてください。"
    elif response.startswith("search["):
        prompt = "observation：\n"
        idx = response.split("[")[-1].split("]")[0]
        if idx in env.page_dict:
            prompt += env.page_dict[idx].getSummaryPrompt()
            env.previous_page = copy.deepcopy(env.current_page)
            env.current_page = env.page_dict[idx]
        else:
            env.previous_page = copy.deepcopy(env.current_page)
            try:
                env.current_page = model.Page(env.url, env.current_page.link_dict[idx].get("href").replace(env.url,""))
            except:
                print("invalid search number : ", idx)
                print(env.current_page.link_dict)
            env.page_dict[idx] = copy.deepcopy(env.current_page)
        prompt += env.current_page.getSummaryPrompt()
    elif response.startswith("go_back_to_previous_page[]"):
        prompt = "observation：\n"
        tmp = copy.deepcopy(env.previous_page)
        env.previous_page = copy.deepcopy(env.current_page)
        env.current_page = tmp
        prompt += env.current_page.getSummaryPrompt()
        return prompt
    elif response.startswith("go_back_to_main_page[]"):
        prompt = "observation：\n"
        env.previous_page = copy.deepcopy(env.current_page)
        env.current_page = copy.deepcopy(env.page_dict[""])
        prompt += env.current_page.getSummaryPrompt()
        return prompt
    else:
        prompt = "observation:Error:Invalid action. \nPlease choose one action from the following action list.\n"
        prompt += "-------- action format ----------"
        prompt += "think[your thought]\n"
        prompt += "analyze_search_index[your analysis]"
        prompt += "search[番号]\n"
        prompt += "go_back_to_main_page[]\n"
        prompt += "go_back_to_previous_page[]\n"
    return prompt