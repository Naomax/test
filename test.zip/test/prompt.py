import tool
import model
import copy
import react
from urllib.parse import urljoin
import traceback
def reset(env):
    messages = [{"role":"system", "content": env.system}]
    #question = "yahooニュースサイトの中から色々な記事を集めてください。記事は半導体関係,ITやAI,景気動向に近ければ近いほど評価されます。ステップに分けて考えて進めてください。一度に複数の行動を選択してはいけません。決してあきらめないでください。\n下記の回答フォーマットから、行動を選択してください。\n"
    question = "yahooニュースサイトの中からあなたの興味・関心に従って色々な記事を集めてください。ステップに分けて考えて進めてください。一度に複数の行動を選択してはいけません。決してあきらめないでください。\n下記の回答フォーマットから、行動を選択してください。\n"
    question += "現在のページは下記の通りです。\n"

    question += env.current_page.getSummaryPrompt()

    question += "-------- action format ----------\n"
    question += "think[your thought]\n\n"
    question += "analyze_search_index[your analysis]\n\n"
    question += "search[ページ番号]"
    #question += "go_back_to_main_page[]\n"
    #question += "go_back_to_previous_page[]\n"

    messages.append({'role':'user', 'content': question})
    messages.append({'role':'assistant', 'content': "think[ITやAI,半導体は、産業の基盤になっており、身近なもののあらゆるものがその技術の恩恵を受けています。また、安全保障や外交問題にも大きな影響を与えています。]"})
    messages.append({'role':'user', 'content': "observation：OKです。続けてください。"})

    return messages

def getScore(summary):
    messages = [{'role':'system', 'content': "あなたは、ITやAI,半導体,景気動向について調査する優秀なジャーナリストです。"}]
    messages.append({'role':'user', 'content': f"以下の記事に関して、あなたの調査対象として適切でしょうか。関連度合い、重要度合いを回答フォーマットに従って0～1の数値で答えてください。\n--回答フォーマット--\nscore:XXX\nreason:XXX\n --記事の内容--\n{summary}"})
    response = react.client.chat.completions.create(
        model = "gpt-4o-mini",
        messages = messages,
        temperature = 0.1
    )
    response_message = response.choices[0].message.content.strip()
    score = response_message.split(":")[1].split("\n")[0]
    reason = response_message.split(":")[-1]
    return score, reason

def summarize(title, html):
    messages = []
    messages.append({'role':'user', 'content': f"yahooのニュースサイトのhtmlをタイトルと一緒に送ります。。タイトルと関係のない部分は省いて内容を要約してください。タイトルはいらないので内容の要約だけ答えてください。\nタイトル：{title}\n 記事の内容:\n{html}"})
    response = react.client.chat.completions.create(
        model = "gpt-4o-mini",
        messages = messages,
        temperature = 0.1
    )
    print(response.choices[0].message.content.strip())
    return response.choices[0].message.content.strip()

def getObservation(env, response):
    if response.count("[") > 1:
        prompt = "observation:Error:Invalid action. Several actions were found. \nPlease choose one action from the following action list.\n"
        prompt += "-------- action format ----------\n"
        prompt += "think[your thought]\n\n"
        prompt += "analyze_search_index[your analysis]\n\n"
        prompt += "search[ページ番号]"
        #prompt += "go_back_to_main_page[]\n"
        #prompt += "go_back_to_previous_page[]\n"
        return prompt
    if response.startswith("think[") or response.startswith("analyze_search_index["):
        prompt = "observation：OKです。続けてください。"
    elif response.startswith("search["):
        prompt = "observation：\n"
        idx = response.split("[")[-1].split("]")[0]
        page = env.current_page.url
        if f"{page}_{idx}" in env.page_dict:
            prompt += env.page_dict[f"{page}_{idx}"].getSummaryPrompt()
            env.previous_page = copy.deepcopy(env.current_page)
            env.current_page = env.page_dict[f"{page}_{idx}"]
        else:
            #"print("invalid search number : ", idx)
            #print("page dict", env.page_dict)
            #exit()
            env.previous_page = copy.deepcopy(env.current_page)
            try:
                absolute_url = urljoin(model.base_url, env.current_page.link_dict[idx].get("href"))
                env.current_page = model.Page(absolute_url)
                env.page_dict[f"{page}_{idx}"] = copy.deepcopy(env.current_page)
            except:
                traceback.print_exc()
                print("invalid search number : ", idx)
                print(env.current_page.link_dict)
        prompt += env.current_page.getSummaryPrompt()
    elif response.startswith("go_back_to_previous_page[]"):
        prompt = "observation：\n"
        tmp = copy.deepcopy(env.previous_page)
        env.previous_page = copy.deepcopy(env.current_page)
        env.current_page = tmp
        prompt += env.current_page.getSummaryPrompt()
        return prompt
    elif response.startswith("go_back_to_main_page[]"):
        prompt = "observation：\n"
        env.previous_page = copy.deepcopy(env.current_page)
        env.current_page = copy.deepcopy(env.page_dict[""])
        prompt += env.current_page.getSummaryPrompt()
        return prompt
    else:
        prompt = "observation:Error:Invalid action. \nPlease choose one action from the following action list.\n"
        prompt += "-------- action format ----------\n"
        prompt += "think[your thought]\n\n"
        prompt += "analyze_search_index[your analysis]\n\n"
        prompt += "search[ページ番号]"
        #prompt += "go_back_to_main_page[]\n"
        #prompt += "go_back_to_previous_page[]\n"
    return prompt