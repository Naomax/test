
import tkinter
from PIL import Image, ImageTk
import random
import time
import copy
import traceback
# 辞書のキー定義
KEY_IMAGE = 'image'
KEY_POSITION = 'position'

chunk_size = 28

def getTextMessage():
    text = ""
    with open("response", "r", encoding = "utf-8") as fi:
        for row in fi:
            text += row
    return text.replace("\n","")

class TransparentWindow():
    """透過画面"""

    FRAME_OFFSET = -2
    BG_COLOR = "black"

    def __init__(self, main, items, position=(0, 0), size=(0, 0),
                 text_message=None, text_position=(0, 0)):
        """コンストラクタ"""

        self.main = main
        self.cnt = 0
        main.config(bg=self.BG_COLOR)
        self.items = items
        self.window_position = position
        self.window_size = size
        self.text_message = text_message
        self.prev_text_message = getTextMessage()
        self.text_position = text_position

        self.timre_id = None

        self.main.geometry(str(self.window_size[0]) + "x" +
                           str(self.window_size[1]) + "+" +
                           str(self.window_position[0]) + "+" +
                           str(self.window_position[1]))

        self.main.wm_overrideredirect(True)
        # 透過表示(くり抜き)色を指定
        self.main.wm_attributes("-transparentcolor",
                                self.BG_COLOR, "-topmost", True)
        # ウィンドウ全体が透過される
        # self.main.wm_attributes("-alpha", 0.1)

        self.init_canvas(self.main)

        self.update_canvas()

    def init_canvas(self, frame):
        """canvas初期化"""

        self.photo_images = []

        # canvas作成
        self.canvas = tkinter.Canvas(
            frame,
            width=self.window_size[0],
            height=self.window_size[1],
            bg=self.BG_COLOR
        )

        # 枠を消すためにマイナス値を指定
        self.canvas.place(x=self.FRAME_OFFSET,
                          y=self.FRAME_OFFSET)
        # クリックイベント
        self.canvas.bind('<Button-1>', self.click_canvas_event)

    def click_canvas_event(self, event):
        """canvasクリックイベント"""

        print("click:(x:" + str(event.x) + ",y=" + str(event.y) + ")")

        if self.timre_id:
            self.main.after_cancel(self.timre_id)
            self.timre_id = None

        self.main.quit()

    def update_canvas(self):
        """canvas描画メソッド"""

        # canvasに画像を描画
        self.photo_images = []
        self.canvas.delete("all")
        for item in self.items:
            photo_image = ImageTk.PhotoImage(image=item[KEY_IMAGE])
            self.photo_images.append(photo_image)

            self.canvas.create_image(
                item[KEY_POSITION][0],
                item[KEY_POSITION][1],
                image=photo_image)

        # canvasにテキストを描画
        # index = random.randint(0, len(self.text_messages)-1)
        text_message = getTextMessage()
        if self.prev_text_message != text_message:
            with open("status", "w", encoding = "utf-8") as fo:
                fo.write("wait")
            self.prev_text_message = text_message
            self.cnt = 0
            self.text_message = ""
        if self.cnt < len(text_message):
            self.text_message += text_message[self.cnt]
            self.cnt += 1
        else:
            with open("status", "w", encoding = "utf-8") as fo:
                fo.write("ok")
        if self.cnt != 0 and self.cnt%chunk_size == 0:
            self.text_message += "\n"
            if self.cnt//chunk_size > 2:
                self.text_message = self.text_message[chunk_size+2:]
        self.canvas.create_text(
            self.text_position[0], self.text_position[1],
            text= self.text_message,
            font = ("Meiryo", 20),
            fill = "blue",
            anchor = "w")
        self.timre_id = self.main.after(10, self.update_canvas)

def run():
    # 画像ファイルを開く
    character = Image.open("./character.png")
    # サイズ調整 1/4
    character = character.resize(
        (int(character.width / 2),
         int(character.height / 2)),
        Image.HAMMING)

    balloon = Image.open("./balloon.png")
    # サイズ調整 1/2
    balloon = balloon.resize(
        (int(balloon.width*1.8),
         int(balloon.height*1.5)),
        Image.HAMMING)

    image_items = []
    image_items.append({KEY_IMAGE: character,
                        KEY_POSITION: ((character.width / 2) + (balloon.width),
                                       character.height / 2)})
    image_items.append({KEY_IMAGE: balloon,
                        KEY_POSITION: (balloon.width / 2, character.height / 2)})

    root = tkinter.Tk()

    window_size = (character.width + balloon.width,
                   max(character.height, balloon.height))

    window_position = (root.winfo_screenwidth() - window_size[0] - 100,
                       root.winfo_screenheight() - window_size[1] - 50)

    # 透過画面表示
    TransparentWindow(main=root,
                      items=image_items,
                      position=window_position,
                      size=window_size,
                      text_message = "",
                      text_position=(40, 100))
    print("before main loop")
    root.mainloop()
    print("after main loop")

if __name__ == "__main__":
    with open("response", "w", encoding = "utf-8") as fo:
        fo.write("私はAIエージェントです。これからYahooのニュースサイトの中から、半導体やAI, ITに関係するニュースを集めて調査します。")
    run()